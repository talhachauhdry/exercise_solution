let name: string = "Muhammad Talha";
console.log(name.toLowerCase());
console.log(name.toUpperCase());
console.log(name.charAt(0).toUpperCase() + name.slice(1).toLowerCase());