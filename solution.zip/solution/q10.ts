// Program 1: Prints a personal greeting
let name: string = "Talha";
console.log(`Hello, ${name}!`);

// Program 2: Calculates the sum of two numbers
let num1: number = 5;
let num2: number = 3;
let sum: number = num1 + num2;
console.log(`The sum of ${num1} and ${num2} is ${sum}.`);
