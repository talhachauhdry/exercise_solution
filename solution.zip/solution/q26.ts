const alien_color = 'green';

if (alien_color === 'green') {
  console.log('The player just earned 5 points!');
}
