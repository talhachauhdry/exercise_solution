let array: number[] = [1, 2, 3];
console.log(array[3]); // Produces an index error
