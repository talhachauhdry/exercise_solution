let mountains: string[] = ["Everest", "K2", "Matterhorn", "Kilimanjaro"];
console.log(mountains);
