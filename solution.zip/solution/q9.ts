let favoriteNumber: number = 14;
console.log(`My favorite number is 14 because its birth date ${favoriteNumber}.`);
