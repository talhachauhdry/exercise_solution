let famous_person: string = 'Francis Bacon';
let quote: string = 'Knowledge is power.';
let message: string = `${famous_person} once said, "${quote}"`;
console.log(message);
