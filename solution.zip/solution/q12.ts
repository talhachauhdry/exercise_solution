let names: string[] = ["Talha", "Mutti", "Ali"];
let message: string = "Hello guys, ";
for (let name of names) {
  console.log(`${message}${name}!`);
}
