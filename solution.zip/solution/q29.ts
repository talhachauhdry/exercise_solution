const favorite_fruits = ['banana', 'apple', 'mango'];

if (favorite_fruits.includes('banana')) {
  console.log('You really like bananas!');
}

if (favorite_fruits.includes('apple')) {
  console.log('You really like apples!');
}

if (favorite_fruits.includes('mango')) {
  console.log('You really like mangoes!');
}
