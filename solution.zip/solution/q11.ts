let names: string[] = ["Talha", "Mutti", "Ali"];
for (let name of names) {
  console.log(name);
}
