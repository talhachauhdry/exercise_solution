let guests: string[] = ["Talha", "Mutti", "Ali"];
console.log(`Number of people invited to dinner: ${guests.length}`);
