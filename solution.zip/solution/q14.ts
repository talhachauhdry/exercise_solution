let guests: string[] = ["Albert Einstein", "Leonardo da Vinci", "Marie Curie"];
for (let guest of guests) {
  console.log(`Dear ${guest}, you are invited to dinner.`);
}
