let name: string = "\t   Muhammad Talha   \n";
console.log(name);
console.log(name.trim());
