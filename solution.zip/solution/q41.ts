function show_magicians(magicians: string[]): void {
    for (const magician of magicians) {
      console.log(magician);
    }
  }
  
  const magicians = ["Talha", "Mutti", "Ali"];
  show_magicians(magicians);
  