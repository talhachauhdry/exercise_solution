let name: string = "Eric";
console.log(`Hello ${name}, would you like to learn some Python today?`);