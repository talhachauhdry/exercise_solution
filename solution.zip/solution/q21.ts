let car: object = { brand: "Tesla", model: "Model S", year: 2023 };
let person: object = { name: "Talha", age: 30, occupation: "Engineer" };
console.log(car);
console.log(person);
