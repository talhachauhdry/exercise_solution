let transportation: string[] = ["car", "motorcycle", "bicycle"];
for (let item of transportation) {
  console.log(`I would like to own a ${item}.`);
}
