const favorite_pizzas = ['pepperoni', 'margherita', 'vegetable'];

for (const pizza of favorite_pizzas) {
  console.log(`I like ${pizza} pizza.`);
}

console.log(`I really love pizza!`);
