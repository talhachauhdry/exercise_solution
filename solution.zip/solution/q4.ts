let quote: string = 'Knowledge is power.';
let author: string = 'Francis Bacon';
console.log(`${author} once said, "${quote}"`);
